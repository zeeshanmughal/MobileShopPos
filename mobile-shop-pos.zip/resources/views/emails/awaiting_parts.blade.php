<!DOCTYPE html>
<html>
<head>
</head>
<body>
    <div class="container" style="padding: 1rem; background: #f5f5f5;">
        <p>Awaiting Parts!</p>
        <p>
            Welcome to Laravel. This is a demo of Awaiting parts emails through
            the Mailgun email service.
        </p>
    </div>
</body>
</html>