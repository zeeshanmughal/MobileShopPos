<!-- resources/views/pdf/bill_details.blade.php -->
<!DOCTYPE html>
<html>
<head>
    <title>Bill Details</title>
</head>
<body>
    <h1>Bill Details</h1>
    <p>Customer Name: {{ $billDetails->id }}</p>
    <!-- Add other bill details as needed -->
</body>
</html>