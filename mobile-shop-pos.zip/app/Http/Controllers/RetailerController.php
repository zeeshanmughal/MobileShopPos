<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use App\Models\Item;
use App\Models\User;
use App\Models\Ticket;
use App\Models\Customer;
use App\Models\BillDetail;
use App\Models\DeviceIssue;
use App\Models\PaymentPlan;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Models\ServiceDetail;
use App\Models\CustomerAddress;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use App\Models\CustomerAdditionalInformation;

class RetailerController extends Controller
{
    //
    public function dashboard(){
        $total_customers = Customer::where('walk_in_customer',0)->count();
        $total_walkin = Customer::where('walk_in_customer',1)->count();
        $total_items = Item::count();

        $paymentPlans = PaymentPlan::all();

        

        return view('retailer.dashboard',compact('total_customers','total_walkin','total_items'));
    }


    public function customers(){
        return view('retailer.customer_create');
    }

    public function walkInByRetailer(){
        $deviceIssues = DeviceIssue::all();
        $inventoryItems = Item::all();

        return view('retailer.walkIn_by_retailer',compact('deviceIssues','inventoryItems'));
    }


    public function serviceDetailStore(Request $request){

        $customer = Customer::where('id', $request->customer_id)->first();
        if($customer){

            if ($request->hasFile('driving_license')) {
                $drivingLicenseFilePath = saveImage($request->file('driving_license'), 'customer_identity_images');
                if ($customer->driving_license) {
                    $previousLicenseFile = $customer->driving_license;
                    if(File::exists($previousLicenseFile)){
                        File::delete($previousLicenseFile);
                    }
                  
                }
            } elseif ($customer->driving_license) {
                $drivingLicenseFilePath = $customer->driving_license;
            } else {
                $drivingLicenseFilePath = null;
            }

            $dataCustomer = [
                'first_name' =>$request->first_name,
                'last_name' =>$request->last_name,
                'email' =>$request->email,
                'country_code' =>$request->country,
                'phone' =>$request->phone,
                'driving_license' => $drivingLicenseFilePath,
            ];

              $conditionCustomer = [
                'id'=>$customer->id
            ];
            $customer =  Customer::updateOrCreate($conditionCustomer, $dataCustomer);
        
        
            $dataCustomerAddress = [
                'street_address' => $request->street_address,
                'house_number' => $request->house_number,
                'city' => $request->city,
                'state' => $request->state,
                'postcode' => $request->postcode,
                'country' => $request->country,
                'location'=> $request->location,

            ];
            $conditionCustomerAddress = [
                'customer_id'=>$customer->id
            ];
          
            
            $customerAddress =  CustomerAddress::updateOrCreate($conditionCustomerAddress, $dataCustomerAddress);

            if($request->sms_notification == null){
                $sms_notification = 0;
            }else{
                $sms_notification = 1;
            }
            if($request->email_notification == null){
                $email_notification = 0;
            }else{
                $email_notification =1;

            }
            $dataCustomerAdditional = [
                'driving_license' => $drivingLicenseFilePath,
                'sms_notification'=>$sms_notification,
                'email_notification'=>$email_notification,

            ];

              $conditionCustomerAdditional = [
                'customer_id'=>$customer->id
            ];
            
            $customerAdditional = CustomerAdditionalInformation::updateOrCreate($conditionCustomerAdditional, $dataCustomerAdditional);


              // Service Details
              if ($request->customer_type == 'walk-in-by-retailer') {

                $serviceDetails = $request->input('service_details');
                if(sizeof($serviceDetails) > 0){
                    foreach($serviceDetails as $index => $detail){
                        $deviceIssue = DeviceIssue::where('id', $detail['device_issue_id'])->first();
                        $serviceDetail = new ServiceDetail();
                        $serviceDetail->user_id = Auth::user()->id;
                        $serviceDetail->customer_id = $customer->id;
                        $serviceDetail->device_name = $detail['device_name'];
                        $serviceDetail->device_issue = $deviceIssue->id;
                        $serviceDetail->imei_or_serial = $detail['imei_or_serial'];
                        $serviceDetail->pickup_days = $detail['pickup_days'];
                        $serviceDetail->pickup_hours = $detail['pickup_hours'];
                        $serviceDetail->inventory_item_id = $detail['inventory_item_id'];
                        $serviceDetail->repair_status = $detail['repair_status'];
                        $serviceDetail->assigned_to = 'Hassam Ali';
                        if($detail['quantity'] == null){
                            $quantity = 1;
                        }else{
                            $quantity = $detail['quantity'];

                        }
                        $serviceDetail->quantity = $quantity;
                        $serviceDetail->price = $detail['price'];
                        if($detail['tax'] == null){
                            $tax = 0;
                        }else{
                            $tax = $detail['tax'];
                        }
                        $serviceDetail->tax = $tax;
                        if ($serviceDetail->save()) {
                            $ticket = new Ticket();
                            $ticket->ticket_id = Str::random(10);
                            $ticket->customer_id = $customer->id;
                            $ticket->user_id = Auth::user()->id;
                            $ticket->service_detail_id = $serviceDetail->id;
                            $ticket->device_name = $serviceDetail->device_name;
                            $ticket->assigned_to = Auth::user()->id;
                            $ticket->ticket_status = 'pending';
                            $ticket->ticket_purpose = 'repair';

                            $ticket->created_date = $request->created_on;

                            $ticket->due_date = $serviceDetail->pickup_time;
                            $ticket->select_criteria = 'select_criteria';
                            if($ticket->save()){
                                $billDetail = new BillDetail();
                                $billDetail->customer_id = $customer->id;
                                $billDetail->user_id = Auth::user()->id;
                                $billDetail->service_detail_id = $serviceDetail->id;
                                $billDetail->ticket_id = $ticket->id;
                                $billDetail->price = $serviceDetail->price;
                                $billDetail->quantity = $serviceDetail->quantity;
                            
                                $billDetail->tax = $tax;
                                if($request->bill_discount == null){
                                    $billDiscount = 0;
                                }else{
                                    $billDiscount = $request->bill_discount;
                                }
                                $billDetail->discount= $billDiscount;
                                if($request->total_paid == null){
                                    $totalPaid = 0;
                                }else{
                                    $totalPaid = $request->total_paid;
                                }
                                $billDetail->total_paid = $totalPaid;
                                $billDetail->paid_by = 'cash';
                                $billDetail->save();
                            }

                        

                        }
                        
                    }
                }
        
            }
        return redirect()->back()->with('success', 'Record added successfully.');

        }else{
        return redirect()->back()->with('error', 'Customer data not found.');

        }

    }


    public function showProfile(){
        $user = Auth::user();
        if($user){
            return view('retailer.profile',compact('user'));
        }

    }

    public function updateProfile(Request $request){



        
    }
}
